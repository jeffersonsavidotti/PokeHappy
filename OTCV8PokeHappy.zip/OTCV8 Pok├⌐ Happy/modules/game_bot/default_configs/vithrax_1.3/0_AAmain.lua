-- main tab
UI.Label("Vithrax CFG v1.3 \n \n Scripting Service: \n Vithrax#5814")

UI.Separator()



